var os = require('os')
var hostname = os.hostname()
console.log("Hello from " + hostname)